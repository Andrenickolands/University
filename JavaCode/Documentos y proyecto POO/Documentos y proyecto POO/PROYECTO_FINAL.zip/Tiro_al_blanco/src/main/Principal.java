package main;

import interfaces.FormInicio;
import interfaces.Instrucciones_TAB;
import interfaces.Tablero;

public class Principal {

    public static void main(String[] args) {

        Instrucciones_TAB inicio = new Instrucciones_TAB();
        inicio.setVisible(true);
    }
    
}

